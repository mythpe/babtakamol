<?php

/**
* WPBakery Page Builder Ohio Split Box Column Inner shortcode view
*/

?>
<div class="vc_col-md-6 split-box-container">
	<div class="parallax-bg"></div>
	<div class="content">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>