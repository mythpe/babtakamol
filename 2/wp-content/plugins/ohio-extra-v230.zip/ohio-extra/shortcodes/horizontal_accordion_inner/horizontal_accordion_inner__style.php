<?php

/**
* WPBakery Page Builder Ohio Accordion Inner shortcode custom style
*/

$_style_block = '';


OhioLayout::append_to_shortcodes_css_buffer( $_style_block );