<?php

/**
* WPBakery Page Builder Ohio Carousel Inner shortcode custom styles
*/
