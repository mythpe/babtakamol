<?php

/**
* WPBakery Page Builder Ohio Vertical Fullscreen Slider shortcode custom style
*/

$_style_block = '';



OhioLayout::append_to_shortcodes_css_buffer( $_style_block );