<?php

/**
* WPBakery Page Builder Ohio Split Box Column shortcode view
*/

?>
<div class="vc_col-md-6 vc_col-sm-12 split-box-container">
	<div class="split-box-inner">
		<div class="parallax-bg"></div>
		<div class="content">
			<?php echo do_shortcode( $content ); ?>
		</div>
	</div>
</div>