<div class="ohio-process-sc process">

    <h6 class="process-number heading-sm"><?php echo $settings['number']; ?></h6>
    <h3 class="process-headline"><?php echo $settings['headline']; ?></h3>
    <p class="process-description"><?php echo $settings['description']; ?></p>

</div>