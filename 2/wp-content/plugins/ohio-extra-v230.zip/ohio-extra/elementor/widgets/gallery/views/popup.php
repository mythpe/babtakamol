<div class="ohio-gallery-opened-sc clb-popup clb-gallery-lightbox" 
	id="<?php echo $gallery_uniqid; ?>" 
	data-options='<?php echo $gallery_json; ?>'>
	<div class="close close-bar">
		<div class="clb-close btn-round round-animation circle-animation">
			<i class="ion ion-md-close"></i>
		</div>
		<div class="expand btn-round round-animation circle-animation vc_hidden-xs">
			<i class="ion ion-md-expand"></i>
		</div>
	</div>
	<div class="clb-popup-holder"></div>
</div>
